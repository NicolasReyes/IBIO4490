Total: (5.0)
- Introduction (1.5): 
- Method (1.0):
- Discussion and Evaluation(2.5):