run('vlfeat/toolbox/vl_setup')
% REMEMER TO INCLUDE THIS LINE AT THE END OF YOUR .bashrc FILE: 
% export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/afromero/vlfeat/toolbox/mex/mexa64
% Create a SymLink of vlfeat folder into your CODE_FOLDER. (This must be in the same direction as the first line)
